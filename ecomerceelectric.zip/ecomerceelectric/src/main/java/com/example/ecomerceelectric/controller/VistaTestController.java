package com.example.ecomerceelectric.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class VistaTestController {

    @GetMapping("/clientes")
    public String verClientes(Model model) {
        return "clientes"; // Busca clientes.html en templates
    }

    @GetMapping("/categorias")
    public String verCategorias(Model model) {
        return "categorias"; // Busca categorias.html en templates
    }

    @GetMapping("/productos")
    public String verProductos(Model model) {
        return "productos"; // Busca productos.html en templates
    }

    @GetMapping("/proveedores")
    public String verProveedores(Model model) {
        return "proveedores"; // Busca proveedores.html en templates
    }
}